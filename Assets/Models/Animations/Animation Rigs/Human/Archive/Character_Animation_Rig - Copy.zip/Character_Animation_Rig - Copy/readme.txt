!!!SET UP AXIS TO Z IN PREFERENCES>SETTINGS!!!


Before exporting the character for the engine, 
make sure that you resize the armature joint to 92.634 
along the x, y, and z scale.

Any models made in Blender that youre importing need to 
be scaled down to 0.2698. I apologize for the slight mess, 
but it is what it is.
